# JIM 2.0 — انتشار واقعی

## 1) سرور
- `server/.env.production.example` را به `.env` تبدیل کنید و `JWT_SECRET` و `PUBLIC_BASE_URL` را تنظیم کنید.
- برای شروع سریع: `docker compose up -d --build` در پوشه `jim_app`.
- برای انتشار ابری، `server/render.yaml` نمونهٔ استقرار Render است.
- در تولید، HTTPS و یک TURN server برای تماس WebRTC لازم است.

## 2) پیامک OTP
در نسخهٔ توسعه، کد OTP در لاگ سرور چاپ می‌شود. قبل از انتشار عمومی باید `SMS_PROVIDER` را به سرویس پیامکی واقعی متصل کنید و کلیدها را فقط در Secret Manager قرار دهید.

## 3) Push
ساختار ذخیرهٔ FCM token در سرور آماده است. برای ارسال واقعی اعلان‌ها باید Firebase Admin و Service Account محیط تولید تنظیم شود.

## 4) Android
در محیطی که Android SDK در دسترس باشد:
`cd android && gradle assembleRelease bundleRelease`

یا GitHub Actions workflow با نام `JIM Android Release` را اجرا کنید؛ APK و AAB به‌عنوان artifact تحویل می‌شوند.

## 5) اتصال اپ به سرور
قبل از Build نهایی، مقدار `window.JIM_API` در `web/index.html` را به آدرس HTTPS سرور خود تنظیم کنید، سپس همان فایل را در `android/app/src/main/assets/` کپی کنید.
