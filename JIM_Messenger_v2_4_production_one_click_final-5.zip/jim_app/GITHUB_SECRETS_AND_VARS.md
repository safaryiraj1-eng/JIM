# تنظیمات GitHub برای ساخت نسخه واقعی جیم

## Variables

`JIM_API_URL` = آدرس HTTPS سرور جیم، مثال: `https://api.example.com`

`JIM_TURN_URLS` = آدرس‌های STUN/TURN، جداشده با کاما

## Secrets

`JIM_KEYSTORE_BASE64` = Base64 کلید امضای Release

`JIM_KEY_ALIAS` = نام alias کلید

`JIM_STORE_PASSWORD` = رمز keystore

`JIM_KEY_PASSWORD` = رمز key

`FIREBASE_GOOGLE_SERVICES_JSON_B64` = Base64 فایل `google-services.json` برنامه Android با package `com.jim.app`

`JIM_TURN_USERNAME` و `JIM_TURN_CREDENTIAL` = مشخصات TURN در صورت استفاده

## Server secrets

در Render/سرور این‌ها را تنظیم کنید:

`JWT_SECRET`
`PUBLIC_BASE_URL=https://...`
`CORS_ORIGIN=https://...`
`SMS_PROVIDER=webhook`
`SMS_HTTP_URL`
`SMS_HTTP_TOKEN`
`FIREBASE_SERVICE_ACCOUNT_JSON`

## نتیجه

بعد از تنظیم `JIM_API_URL`، در Actions اجرای `JIM - One Click APK` را بزنید.
`JIM-installable-APK` برای نصب مستقیم است و `JIM-release-files` برای Release APK/AAB.
