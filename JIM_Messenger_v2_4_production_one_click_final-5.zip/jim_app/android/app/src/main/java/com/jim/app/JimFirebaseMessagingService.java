package com.jim.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class JimFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL = "jim_messages";

    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        getSharedPreferences("jim_native", MODE_PRIVATE).edit().putString("fcm_token", token).apply();
        uploadToken(token);
    }

    private void uploadToken(String token) {
        String jwt = getSharedPreferences("jim_native", MODE_PRIVATE).getString("jwt", "");
        String api = getSharedPreferences("jim_native", MODE_PRIVATE).getString("api", BuildConfig.JIM_API);
        if (jwt == null || jwt.isEmpty()) return;
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL(api.replaceAll("/$", "") + "/api/push-token");
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                c.setRequestProperty("Authorization", "Bearer " + jwt);
                c.setDoOutput(true);
                String body = "{\"token\":\"" + token.replace("\\", "\\\\").replace("\"", "\\\"") + "\",\"platform\":\"android\"}";
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                c.getResponseCode();
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        String title = message.getNotification() != null && message.getNotification().getTitle() != null ? message.getNotification().getTitle() : "جیم";
        String body = message.getNotification() != null && message.getNotification().getBody() != null ? message.getNotification().getBody() : "پیام جدید داری";
        show(title, body);
    }

    private void show(String title, String body) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(new NotificationChannel(CHANNEL, "پیام‌های جیم", NotificationManager.IMPORTANCE_HIGH));
        }
        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(com.jim.app.R.drawable.ic_jim)
                .setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_HIGH);
        manager.notify((int)(System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
