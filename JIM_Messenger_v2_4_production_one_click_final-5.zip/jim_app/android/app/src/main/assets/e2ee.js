/* JIM E2EE foundation. Use an audited Signal-style protocol before production claims of full E2EE. */
export async function generateIdentity(){return crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveKey','deriveBits'])}
export async function exportPublicKey(key){return crypto.subtle.exportKey('jwk',key)}
export async function importPublicKey(jwk){return crypto.subtle.importKey('jwk',jwk,{name:'ECDH',namedCurve:'P-256'},true,[])}
export async function deriveChatKey(privateKey,peerPublic){return crypto.subtle.deriveKey({name:'ECDH',public:peerPublic},privateKey,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
export async function encryptText(key,text){const iv=crypto.getRandomValues(new Uint8Array(12));const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,new TextEncoder().encode(text));return {iv:Array.from(iv),cipher:Array.from(new Uint8Array(ct))}}
export async function decryptText(key,payload){const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:new Uint8Array(payload.iv)},key,new Uint8Array(payload.cipher));return new TextDecoder().decode(pt)}
