window.JIM_API = localStorage.getItem("jim_api") || "https://api.example.com";
window.JIM_ICE_SERVERS = [{ urls: "stun:stun.l.google.com:19302" }];
