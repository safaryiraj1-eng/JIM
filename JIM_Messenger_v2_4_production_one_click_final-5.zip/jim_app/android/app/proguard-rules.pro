# JIM currently uses WebView/Java only; keep default Android rules.
