#!/usr/bin/env bash
set -euo pipefail
OUT="${1:-jim-release.keystore}"
ALIAS="${JIM_KEY_ALIAS:-jimrelease}"
STORE_PASS="${JIM_STORE_PASSWORD:-}"
KEY_PASS="${JIM_KEY_PASSWORD:-}"
if [[ -z "$STORE_PASS" || -z "$KEY_PASS" ]]; then
  echo 'Set JIM_STORE_PASSWORD and JIM_KEY_PASSWORD before running.' >&2
  exit 1
fi
keytool -genkeypair -v -keystore "$OUT" -storetype PKCS12 -alias "$ALIAS" -keyalg RSA -keysize 3072 -validity 10000 -storepass "$STORE_PASS" -keypass "$KEY_PASS" -dname 'CN=JIM, OU=JIM, O=JIM, L=Zanjan, ST=Zanjan, C=IR'
echo "Created $OUT with alias $ALIAS"
