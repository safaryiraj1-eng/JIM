# جیم — راه‌اندازی نسخه قابل انتشار

## 1) سرور

سرور داخل `server/` است و Docker/Render آماده دارد.

متغیرهای اصلی تولید:

- `JWT_SECRET`: راز طولانی و تصادفی
- `PUBLIC_BASE_URL`: آدرس HTTPS سرور جیم
- `CORS_ORIGIN`: آدرس وب جیم
- `SMS_PROVIDER=webhook` برای ارسال SMS واقعی
- `SMS_HTTP_URL` و `SMS_HTTP_TOKEN`: آدرس/کلید سرویس SMS
- `FIREBASE_SERVICE_ACCOUNT_JSON`: JSON حساب سرویس Firebase برای Push
- `DATA_DIR=/var/data`
- `UPLOAD_DIR=/var/data/uploads`

در Render فایل `render.yaml` دیسک پایدار برای دیتابیس و فایل‌ها می‌خواهد.

## 2) Firebase

در Firebase یک Android App با package name `com.jim.app` بسازید و `google-services.json` را بگیرید.

برای GitHub Actions، محتوای فایل را Base64 کنید و در Secret زیر قرار دهید:

`FIREBASE_GOOGLE_SERVICES_JSON_B64`

برای Push سمت سرور، JSON حساب سرویس را در Secret/Environment زیر قرار دهید:

`FIREBASE_SERVICE_ACCOUNT_JSON`

## 3) کلید امضای APK

کلید انتشار را هرگز داخل repository قرار ندهید. با ابزار زیر آن را بسازید:

`tools/generate-release-keystore.sh`

سپس Base64 فایل keystore را در GitHub Secret زیر قرار دهید:

`JIM_KEYSTORE_BASE64`

و این سه Secret را نیز بسازید:

`JIM_KEY_ALIAS`

`JIM_STORE_PASSWORD`

`JIM_KEY_PASSWORD`

## 4) ساخت با یک کلیک

در GitHub به Actions بروید، workflow `JIM - One Click APK` را اجرا کنید و در `api_url` آدرس HTTPS سرور را وارد کنید.

خروجی `JIM-installable-APK` برای نصب مستقیم روی Android است.

خروجی `JIM-release-files` شامل APK/AAB انتشار است. وقتی کلید امضای GitHub Secrets تنظیم شده باشد، وضعیت `SIGNED_RELEASE=true` ثبت می‌شود.

## 5) تماس صوتی/تصویری

برای WebRTC بهتر است TURN واقعی تنظیم شود. در GitHub Variables/Secrets:

`JIM_TURN_URLS`

`JIM_TURN_USERNAME`

`JIM_TURN_CREDENTIAL`

در نبود TURN، فقط STUN پیش‌فرض در پروژه قرار دارد و بعضی شبکه‌ها ممکن است تماس مستقیم را برقرار نکنند.

## 6) رمزنگاری

جیم زیرساخت کلید عمومی را دارد، اما قبل از تبلیغ محصول به عنوان «رمزنگاری سرتاسری کامل مانند پیام‌رسان‌های ممیزی‌شده» باید پروتکل چنددستگاهی/ratchet و ممیزی امنیتی مستقل تکمیل شود.
