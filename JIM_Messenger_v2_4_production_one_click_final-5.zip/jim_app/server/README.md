# JIM Backend

Backend starter برای جیم: ثبت‌نام/ورود با OTP، JWT، دیتابیس SQLite، پیام آنلاین با Socket.IO، آپلود فایل و signaling برای WebRTC.

## اجرا
1. Node.js 20+ نصب کنید.
2. `npm install`
3. `.env.example` را به `.env` کپی کنید و `JWT_SECRET` و `PUBLIC_BASE_URL` را تنظیم کنید.
4. `npm start`

در حالت توسعه، OTP در لاگ سرور چاپ می‌شود. برای انتشار عمومی باید بخش ارسال SMS به سرویس پیامکی واقعی متصل شود.

## نکته امنیتی
این کد اسکلت اجرایی است و قبل از انتشار عمومی باید rate-limit دقیق‌تر، antivirus/file scanning، object storage، HTTPS، مدیریت نشست‌ها، حذف فایل، backup، مانیتورینگ، قوانین حریم خصوصی و تست امنیتی اضافه شود.

## Push Notification
سرور توکن FCM را از `/api/push-token` ذخیره می‌کند. برای ارسال واقعی Push، فایل credentials سرویس Firebase را به‌صورت Secret روی سرور قرار دهید و یک worker/endpoint ارسال FCM فعال کنید.

## رمزنگاری
`../web/e2ee.js` پایه ECDH + AES-GCM و endpoint کلید عمومی را فراهم می‌کند. برای پیام‌رسان عمومی، قبل از اعلام «رمزنگاری سرتاسری واقعی»، باید پروتکل ratchet ممیزی‌شده و مدیریت کلید چنددستگاهی پیاده‌سازی شود.
