# JIM 2.2 – Full Messenger Upgrade

این نسخه نسبت به 2.1 شامل:
- حساب واقعی با OTP و JWT
- پروفایل، username و about
- جستجوی کاربران و ساخت گفتگوی مستقیم
- گروه‌های واقعی و مدیریت اعضا
- پیام‌ها با reply/edit/delete/reaction/read receipt
- ارسال فایل تا 100MB
- Socket.IO realtime
- تماس صوتی/تصویری WebRTC signaling
- کلید عمومی برای زیرساخت رمزنگاری
- Push token registration
- خروجی گرفتن از اطلاعات حساب
- Docker و CI برای ساخت Android

## راه‌اندازی
1. `cd server && cp .env.example .env`
2. `npm install && npm start`
3. مقدار `JIM_API` را در WebView/Android روی آدرس سرور تنظیم کنید.
4. برای SMS واقعی، provider را به سرویس پیامک متصل کنید؛ OTP کنسول فقط توسعه است.
5. برای تماس پایدار روی اینترنت عمومی، TURN server و HTTPS لازم است.
6. برای Push واقعی، Firebase credentials لازم است.

## امنیت
زیرساخت کلید عمومی و E2EE اولیه است؛ قبل از ادعای «رمزنگاری سرتاسری» در فروشگاه باید پروتکل و مدیریت کلید ممیزی امنیتی شود.
