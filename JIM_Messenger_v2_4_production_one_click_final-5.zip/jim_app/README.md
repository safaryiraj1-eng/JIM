# جیم (JIM) — پیام‌رسان فارسی 2.4

جیم یک پروژه پیام‌رسان با پوسته فارسی، چت آنلاین، گروه، فایل، پیام صوتی، تماس WebRTC، پروفایل، جست‌وجو، واکنش و نوتیفیکیشن Firebase است.

## ساخت APK با یک کلیک

Workflow زیر آماده است:

`.github/workflows/build-apk-one-click.yml`

ورودی `api_url` را با آدرس HTTPS سرور وارد کنید. سپس در Artifacts فایل `JIM-installable-APK` را بگیرید.

برای APK/AAB انتشار، Secrets امضای Release را طبق `PRODUCTION_SETUP_FA.md` تنظیم کنید.

## ساخت محلی

پوشه `android` یک پروژه Gradle مستقل است. AGP 8.7.3 با Gradle 8.9 برای API 35 تنظیم شده است. Android Developers اعلام کرده AGP 8.7 از API 35 پشتیبانی می‌کند و Gradle 8.9 را به‌عنوان نسخه پیش‌فرض/موردنیاز خود دارد.

## سرور

```bash
cd server
npm install
cp .env.production.example .env
npm start
```

برای SMS واقعی، `SMS_PROVIDER=webhook` و `SMS_HTTP_URL` را تنظیم کنید.

## نکته مهم انتشار

برای انتشار عمومی باید HTTPS، SMS واقعی، Firebase، TURN و کلید امضای اختصاصی تنظیم شوند. هیچ Secret حساسی داخل repository قرار نگیرد.
