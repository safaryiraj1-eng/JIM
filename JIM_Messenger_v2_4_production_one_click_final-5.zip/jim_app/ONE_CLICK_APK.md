# ساخت APK جیم با یک کلیک

1. کل پوشه `jim_app` را در یک مخزن GitHub قرار دهید.
2. وارد تب **Actions** شوید.
3. گردش‌کار **JIM - One Click APK** را باز کنید.
4. روی **Run workflow** بزنید.
5. پس از پایان، در صفحه اجرای workflow بخش **Artifacts** را باز کنید.
6. `JIM-installable-APK` را دانلود کنید و فایل `JIM.apk` را روی Android نصب کنید.

این workflow به‌صورت خودکار Java 17، Android SDK و Gradle 8.7 را آماده می‌کند و APK را می‌سازد.

> برای انتشار عمومی، سرور جیم باید روی HTTPS قرار گیرد و APK نهایی با کلید امضای اختصاصی منتشر شود.
